from math import *
import math 
x = float(input('Введите значение x для первого графика '))
if x<-2: 
    y = (1/4)*x+(1/2)
elif x >=-2 and x<0:
    y = -sqrt(4-(x+2)**2)+2
elif x >=0 and x<2:
    y = sqrt(4-(x-0)**2)
elif x >=2:
    y = -x+2
else: print("Точка не принадлежит графику")
print("X={0:.2f} Y={1:.2f}".format(x, y))

def bezier_curve(control_points, x):
    n = len(control_points) - 1
    result = 0
    for i in range(n + 1):
        result += control_points[i][1] * binomial_coefficient(n, i) * (1 - t)**(n - i) * t**i
    return result
def binomial_coefficient(n, k):
    return math.comb(n, k)
x = float(input('Введите значение x для второго графика: '))
if x < -2.5:
    y = -(4/5)*x-5
elif -2.5 <= x < 2:
    control_points = [(-2.5, -3), (-2, 0),  (-1.5, 1), (-1, 0), (0, -3), (0.5, -3.5),  (1.5, 0), (2, 6)]
    t = 0.8
    y = bezier_curve(control_points, t)
else:
    y = -2*x + 10

print("X={0:.2f} Y={1:.2f}".format(x, y))