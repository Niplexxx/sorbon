import math
print("Вариант 12")
flag = 0
def is_point_in_circle(x, y, center_x, center_y, radius):
    distance = math.sqrt((x - center_x)**2 + (y - center_y)**2)
    if distance <= radius:
        return True
    else:
        return False

center_x_1 = -5
center_y_1 = 5
center_x_2 = -5
center_y_2 = -5
radius = 5

x = float(input("Введите значение x для точки: "))
y = float(input("Введите значение y для точки: "))

if (is_point_in_circle(x, y, center_x_1, center_y_1, radius)) or (x < 0 and y < 0) or (x > 0 and y > 0) or (is_point_in_circle(x, y, center_x_2, center_y_2, radius)):
     flag = 0
elif (x > -5 and y < 5) or (x < 5 and y > -5):
    flag = 1
print("Точка X={0: 6.2f} Y={1: 6.2f}".format(x, y), end=" ")
if flag == 1:
    print("попадает", end=" ")
else:
    print("не попадает", end=" ")
print("в область.")

print("Вариант 27")
def is_point_in_circle_segment(x, y, center_x, center_y, radius, start_angle1, end_angle1, start_angle2, end_angle2):
    distance = math.sqrt((x - center_x)**2 + (y - center_y)**2)
    if distance > radius:
        return False
    angle = math.degrees(math.atan2(y - center_y, x - center_x))
    if angle < 0:
        angle += 360
    if (start_angle1 <= angle <= end_angle1) or (start_angle2 <= angle <= end_angle2):
        return True
    else:
        return False

center_x = 0
center_y = 0
radius = 5
start_angle1 = 90
end_angle1 = 180
start_angle2 = 270
end_angle2 = 360

x = float(input("Введите значение x для точки: "))
y = float(input("Введите значение y для точки: "))

if is_point_in_circle_segment(x, y, center_x, center_y, radius, start_angle1, end_angle1, start_angle2, end_angle2) or math.sqrt((x - center_x)**2 + (y - center_y)**2) > radius:
    print("Точка ({:.2f}, {:.2f}) попадает.".format(x, y))
else:
    print("Точка ({:.2f}, {:.2f}) не попадает.".format(x, y))