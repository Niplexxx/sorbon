from math import *
import math
print("вариант 12")
a = float(input('Введите параметр а: '))
z=((sin(4*a))/(1+cos(4*a)))*((cos(2*a))/(1+cos(2*a)))
print("Пример 1: {}; {:6.3f}".format(a, z))
x=(3/2)*pi-a
z=(cos(x) / sin(x))
print("Пример 2: {}; {:6.3f}".format(a, z))

print("вариант 27")
a = float(input('Введите параметр a: '))
b = float(input('Введите параметр b: '))
z = (a**(sqrt(math.log(a,b))))-(b**(sqrt(math.log(b,a)))+math.tan(a*b+3*(pi/2)))
print("Пример 1: {}; {}; {:6.3f}".format(a, b, z))
z=math.tan(a*b+(3/2)*pi)
print("Пример 2: {}; {}; {:6.3f}".format(a, b, z))