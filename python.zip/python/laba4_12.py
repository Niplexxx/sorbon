from decimal import Decimal, getcontext

def taylor_series(x, n):
    term = 1
    result = 0
    for i in range(1, n+1):
        term = (-1)**i * ((x + 1)**i) / (i * (x**2))
        result += term
    return result

def generate_table(x_start, x_end, dx, epsilon):
    getcontext().prec = 28  # Устанавливаем точность для Decimal
    print("Таблица значений функции:")
    print("==========================================================")
    print("|    X    |    Значение функции    |  Количество членов  |")
    print("==========================================================")
    x = x_start
    while x <= x_end:
        # Вычисление значения функции и количества просуммированных членов ряда
        n = 1
        series_sum = taylor_series(x, n)
        while abs(taylor_series(x, n+2) - series_sum) >= epsilon:
            n += 2
            series_sum = taylor_series(x, n)
        # Вывод строки таблицы
        print("{:<10.4f} {:<15.4f} {:<10d}".format(x, Decimal(series_sum) * 2, n))
        x += dx
    print("=========================================================")

# Задайте значения интервала, шага и точности
x_start = float(input("Введите начальное значение X: "))
x_end = float(input("Введите конечное значение X: "))
dx = float(input("Введите шаг dx: "))
epsilon = float(input("Введите точность ε: "))

# Генерация таблицы значений
generate_table(x_start, x_end, dx, epsilon)